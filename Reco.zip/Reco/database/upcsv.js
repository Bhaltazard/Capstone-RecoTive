const admin = require("firebase-admin");
const fs = require("fs");

// Inisialisasi aplikasi Firebase
const serviceAccount = require("./path/serviceAccountKey.json");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: "gs://capstone-recotive.appspot.com/",
  databaseURL: "https://capstone-recotive-default-rtdb.asia-southeast1.firebasedatabase.app/"
});

// Referensi ke Firebase Storage
const bucket = admin.storage().bucket();

// Path dan nama file CSV yang ingin diunggah
const filePath = "./image/catrelevance.csv";
const fileName = "catrelevance.csv";

// Baca konten file CSV
fs.readFile(filePath, (err, data) => {
  if (err) {
    console.error("Terjadi kesalahan saat membaca file:", err);
    return;
  }

  // Unggah file ke Firebase Storage
  const file = bucket.file(fileName);
  const options = {
    resumable: false,
    metadata: {
      contentType: "text/csv"
    }
  };

  file.save(data, options, (err) => {
    if (err) {
      console.error("Terjadi kesalahan saat mengunggah file:", err);
      return;
    }

    // Dapatkan URL file yang diunggah
    const expirationDate = new Date("2023-07-12"); // Tanggal kadaluarsa URL file
    file.getSignedUrl({
      action: "read",
      expires: expirationDate
    }, (err, url) => {
      if (err) {
        console.error("Terjadi kesalahan saat mendapatkan URL file:", err);
        return;
      }

      // Simpan URL file ke Firebase Realtime Database
      const db = admin.database();
      const fileRef = db.ref("Data");
      fileRef.set({ url })
        .then(() => {
          console.log("File berhasil ditambahkan ke Firebase Realtime Database.");
        })
        .catch((err) => {
          console.error("Terjadi kesalahan saat menyimpan URL file:", err);
        });
    });
  });
});

// import file csv ke realtime database