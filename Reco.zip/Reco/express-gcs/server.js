const express = require('express');
const { Storage } = require('@google-cloud/storage');
const mysql = require('mysql');

// Inisialisasi aplikasi Express.js
const app = express();

// Konfigurasi Cloud Storage
const storage = new Storage({
  projectId: 'your-project-id',
  keyFilename: 'path/to/serviceAccountKey.json',
});

// Konfigurasi koneksi database Cloud SQL
const dbConfig = {
  host: 'your-cloud-sql-host',
  user: 'your-username',
  password: 'your-password',
  database: 'your-database',
};

// Route untuk mengunggah file ke Cloud Storage
app.post('/upload', (req, res) => {
  // Ambil file dari permintaan (misalnya menggunakan multer middleware)
  const file = req.file;

  // Simpan file ke bucket Cloud Storage
  const bucketName = 'your-bucket-name';
  const fileName = 'your-file-name';

  const bucket = storage.bucket(bucketName);
  const fileStream = bucket.file(fileName).createWriteStream();

  fileStream.on('error', (err) => {
    console.error('Error uploading file:', err);
    res.status(500).send('Error uploading file');
  });

  fileStream.on('finish', () => {
    console.log('File uploaded successfully.');
    res.status(200).send('File uploaded successfully');
  });

  fileStream.end(file.buffer);
});

// Route untuk mengakses data dari Cloud SQL
app.get('/data', (req, res) => {
  // Membuat koneksi ke Cloud SQL
  const connection = mysql.createConnection(dbConfig);

  // Query untuk mengambil data dari basis data
  const query = 'SELECT * FROM your_table';

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error querying database:', err);
      res.status(500).send('Error querying database');
    } else {
      res.status(200).json(results);
    }

    // Tutup koneksi setelah selesai
    connection.end();
  });
});

// Jalankan server Express.js
const port = 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

// menghubungkan database cloud sql dengan cloud storage